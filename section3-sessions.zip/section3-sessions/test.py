
from flask import Flask, render_template, session, redirect, url_for, escape, request
import model
app = Flask(__name__)
app.secret_key = 'jumpjacks'
email = ''
user = model.check_users()
@app.route('/', methods = ['GET', 'POST'])
def index():
   if 'username' in session:
       username = session['username']
       return 'Logged in as ' + username + '<br>' + "<b><a href = '/logout'>click here to log out</a></b>"
   return "You are not logged in <br><a href = '/login'>" + "click here to log in</a>"

@app.route('/login', methods = ['GET', 'POST'])
def login():
   if request.method == 'POST':
      session['username'] = request.form['username']
      return redirect(url_for('index'))
   return render_template('index.html', message = 'Login to the page or sign up!')

@app.route('/logout')
def logout():
   # remove the username from the session if it is there
   session.pop('username', None)
   return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(port = 5002, debug= True)