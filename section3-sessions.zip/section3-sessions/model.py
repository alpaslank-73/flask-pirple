import pymysql 

def getuid(email):
    connection = pymysql.connect( host = 'localhost', port = 3306,
    user = 'alp', passwd = '123456', db = 'todo' )
    cursor = connection.cursor()
    sql = "SELECT `uid` FROM `users` WHERE `email`=%s"
    cursor.execute(sql, (email,))
    uid = cursor.fetchone()
    print(uid, 'aloo1')
    if uid is None:
        #print('No such user')
        return False
    else:
        #password = cursor.fetchone()[0]
        uid = uid[0]
        print(uid, 'aloo2')
        return uid
    connection.close()

def check_users():
    connection = pymysql.connect( host = 'localhost', port = 3306,
    user = 'alp', passwd = '123456', db = 'todo' )
    cursor = connection.cursor()
    sql = 'SELECT email FROM users ORDER BY uid DESC;'
    cursor.execute(sql)
    db_users = cursor.fetchall()
    users = []
    for i in range(len(db_users)):
        person = db_users[i][0]
        users.append(person)
    connection.commit()
    cursor.close()
    connection.close()
    return users

def check_pw(email):
    connection = pymysql.connect( host = 'localhost', port = 3306,
    user = 'alp', passwd = '123456', db = 'todo' )
    cursor = connection.cursor()
    sql = "SELECT `password` FROM `users` WHERE `email`=%s"
    cursor.execute(sql, (email,))
    password = cursor.fetchone()
    #print(password)
    if password is None:
        #print('No such user')
        return False
    else:
        #password = cursor.fetchone()[0]
        password = password[0]
        print(password)
        return password
    connection.close()

def signup(email, password):
    connection = pymysql.connect( host = 'localhost', port = 3306,
    user = 'alp', passwd = '123456', db = 'todo' )
    cursor = connection.cursor()
    sql1 = "SELECT `password` FROM `users` WHERE `email`=%s"
    cursor.execute(sql1, (email,))
    exist = cursor.fetchone()
    if exist is None:
        sql2 = "INSERT INTO `users` (`email`, `password`) VALUES (%s, %s)"
        cursor.execute(sql2, (email, password))
        connection.commit()
        cursor.close
        connection.close
        print('You have succesfully signed up!')
    else:
        print('User already exists!')
        cursor.close
        connection.close()

def addlist(uid,lname):
    connection = pymysql.connect( host = 'localhost', port = 3306,
    user = 'alp', passwd = '123456', db = 'todo' )
    cursor = connection.cursor()
    sql1 = "SELECT `uid` FROM `lists` WHERE `lname`=%s"
    cursor.execute(sql1, (lname,))
    exist = cursor.fetchone()
    if exist is None:
        sql2 = "INSERT INTO `lists` (`uid`, `lname`) VALUES (%s, %s)"
        cursor.execute(sql2, (uid, lname))
        connection.commit()
        cursor.close
        connection.close
        print('List added!')
    else:
        print('List already exists!')
        cursor.close
        connection.close()

def list_users_lists(email):
    uid = getuid(email)
    #print(uid)
    list = []
    connection = pymysql.connect( host = 'localhost', port = 3306,
    user = 'alp', passwd = '123456', db = 'todo' )
    cursor = connection.cursor()
    sql = "SELECT `lname` FROM `lists` WHERE `uid`=%s"
    cursor.execute(sql, (uid,))
    list = cursor.fetchall()
    #print(password)
    if list is None:
        #print('No such user')
        return False
    else:
        print(list)
        return list
    connection.close()

def dellist(lname):  # or lid
    pass

def addtask(text):
    pass

def deltask(tid): # or text
    pass

def updatetask(tid): # or text
    pass
