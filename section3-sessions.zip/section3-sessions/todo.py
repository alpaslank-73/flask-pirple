from flask import Flask, render_template, request, session, redirect, url_for, g
import model

app = Flask(__name__)

app.secret_key = 'jumpjacks'
email = ''
user = model.check_users()

@app.route('/', methods = ['GET', 'POST'])
def home():
    if request.method == 'GET':
        text1 = 'This web application lets you keep track of your things to do.<br><br>'
        text2 = 'In order to use the app you need to be a registered user.<br><br>'
        text3 = 'After signing in you can begin using the application.<br><br>'
        return render_template('index.html', message1=text1, message2=text2, message3=text3)
    else:
        areyouuser = request.form['email']
        pwd = model.check_pw(areyouuser)
        if request.form['password'] == pwd:
            session['email'] = request.form['email']
            return redirect(url_for('lists'))
        # email = request.form['email']
        # password = request.form['password']
        # db_password = model.check_pw(email)
        # print(password, db_password)

        # if password == db_password or 'email' in session:
        #     #return render_template('todo.html')
        #     return redirect(url_for('todo'))
        # else:
        #     error_message = 'Wrong email or password'
        #     return render_template('index.html', err_message = error_message)
    if 'email' in session:
        g.user=session['email']
        #return render_template('todo.html', message = 'Mesaj1')
        return redirect(url_for('lists'))
    return render_template('homepage.html', message = 'Login to the page or sign up!')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        session.pop('email', None)
        areyouuser = request.form['email']
        pwd = model.check_pw(areyouuser)
        if request.form['password'] == pwd:
            session['email'] = request.form['email']
            return redirect(url_for('lists'))
    return render_template('index.html')

@app.before_request
def before_request():
    g.email = None
    if 'email' in session:
        g.email = session['email']

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

@app.route('/about', methods = ['GET'])
def about():
    return render_template('about.html')

@app.route('/terms', methods = ['GET'])
def terms():
    return render_template('terms.html')

@app.route('/privacy', methods = ['GET'])
def privacy():
    return render_template('privacy.html')

@app.route('/signup', methods = ['GET', 'POST'])
def signup():
    if request.method == 'GET':
        return render_template('signup.html', message1 = 'Please sign up')
    else:
        email = request.form["email"]
        password = request.form["password"]
        model.signup(email, password)
        #message = model.signup(email, password)
        return render_template('signup.html', message2 = 'Thanks for signing up. <a href="/login">Click to log in</a>')

# @app.route('/todo', methods = ['GET'])
# def todo():
#     var1 = session['email']
#     print(var1)
#     return render_template('todo.html', message = var1)

@app.route('/lists')
def lists():
    email = session['email']
    lists = model.list_users_lists(email)
    print(lists)
    return render_template('lists.html', lists=lists)

# @app.route('/tasks')
# def tasks():
#     dene1 = request.data
#     print(dene1)
#     # lid = getlid(lname)
#     # print(lname, lid)
#     # tasks = model.tasklist(lid)
#     return render_template('tasks.html', tasks=tasks)

@app.route('/addlist', methods = ['POST'])
def addlist():
    email = session['email']
    uid = model.getuid(email)
    lname = request.form["lname"]
    model.addlist(uid,lname)
    #return render_template('lists.html', message='List added')
    return redirect(url_for('test'))
    
def listitems():
    lname = request.form["lname"]
    #print(lname)
    return render_template('tasks.html', tasks=tasks)

if __name__ == '__main__':
    app.run(debug=True)
